# 向助教确认：数据与评价规则

本清单整合Phase4的 `NEW_PAYLOAD_REQUEST.md` 与 `NLTCP_DECODER_QUESTIONS.md`，用于团队统一询问；**仅保存草稿，尚未发送。** 我们已完成NLTCP S2S单RC、线性/非线性特征拼接及残差融合；当前未发现融合稳定超过115窗口强线性模型，保留了负面结果。

## 必须确认

1. **最终评价目标是什么？** 课程只要求与现有参数的符号LMS比较，还是要求超过经过优化的115窗口Ridge/线性RC？是否接受“实现完整、严格消融、融合无稳定增益”的结论？第二组采用S2S是否符合要求（原参考RC是64APSK W2S）？各组能否统一前端、分段、保护区、解码和固定XY权重后比较？
2. **非法PAM4输出4/5应怎么定义？** 当前源解码为 `abs(q[t]-floor(q[t-1]/2))`，噪声会产生非法状态转换。应按擦除、两个bit全错、丢帧，还是改为有约束序列解码？请给出确定算法/状态转移、初态/终态和计错分母，不能由我们按答案截断或取模。PAM4到bit采用自然二进制还是Gray？是否固定每PAM4两bit、每复符号四bit？
3. **首尾参考如何解释？** 理想v1/v2直接解码仅第1及51200项与PAM4标签不一致：首项缺前驱，末项原因不明。请确认保护/填充/终止规则及正确符号ID；现阶段统一剔除保护区、保留原文件，不擅自修标签。
4. **是否存在完整的不同Tx消息数据？** 509/513/382共用同套参考和标签，只能说明工况差异。若课程要求独立新消息验证，请提供新的payload_id及对应：RX1/RX2完整采样、实际Tx波形、两路原始PAM4标签、编码后理想I/Q符号、采样/符号对应及采集条件。消息随机种子/生成脚本或原标签不同应可验证，而非只更换index。
5. **旧 `data36QAM.txt` 是否另一条消息？** Sheet1/2指向它，后期Sheet3/等高线图指向 `RF0.105_data36QAM.txt`。两波形hash不同、前40000点零延迟相关约−.0068，但这不足以排除成形/载频/移位差异。请明确对应payload与RX index，并补齐对应RX1/RX2、PAM4标签及理想复符号；若没有，请明确它的用途，避免误作新盲测。

前两项决定最终比较与BER表述；第3项决定边界契约；第4–5项是**独立新载荷性能宣称的必要前提**，不是整理现有负面结果报告的阻碍。在规则确认前，继续同时报告固定2-bit上下界、非法率和历史auto BER，不提供未经定义的唯一物理BER。

## 可选补充（增强解释与复现）

- 提供TXT生成/同步/重采样/归一化日志，确认RX文件是否还经过额外非线性处理；RX1/RX2与表中CH1/CH3、CH2衰减栏如何对应？这影响Volterra消融的物理解释。
- Tx成形参数：采样率、sps、RRC滚降/span、载频、相位、帧起点；NLTCP编码器源码、初态和终态。
- 其它 `data36qamQAM.txt`、`data49QAM.txt`、`pre_SNRest_36QAM.txt` 的用途及是否另有完整标签。不同文件名不视为独立消息证明。
- 若提供新载荷，最好区分开发/校准载荷和最终封存载荷，提供多次独立噪声采集；明确是新载荷内训练后测试，还是旧模型直接迁移，两者分别报告。事前约定样本长度与所需不确定度。
- 是否要求完整MATLAB工具箱逐样本对照？当前共享矩阵RC、LMS/Volterra和NLTCP已数值验证，但CAP的rcosdesign与biterr工具箱运行未完成。

## 我们当前的计错做法（便于助教直接确认）

N个有效复符号、E个合法判决错误bit、U个非法I/Q分量：固定bit范围为 `[E/(4N), (E+2U)/(4N)]`，非法率 `U/(2N)`。范围不是置信区间；MATLAB兼容auto按I/Q各自最大整数选位宽，有4/5时可能扩至3位。禁止丢掉非法判决后只报剩余样本BER。若后续明确新规则，可对保存预测做标注清楚的历史重评分，但不能把它叫新盲测或据此继续选模型。

详细证据保留于：

- [Phase4新载荷原清单](/Users/oliver/Desktop/DSP/rc_baseline/runs/phase4_residual_fusion/NEW_PAYLOAD_REQUEST.md)
- [Phase4解码问题原清单](/Users/oliver/Desktop/DSP/rc_baseline/runs/phase4_residual_fusion/NLTCP_DECODER_QUESTIONS.md)
- [Phase2解码审计](/Users/oliver/Desktop/DSP/rc_baseline/runs/phase2_509/decoder_audit.json)
- [Tx文件盘点](/Users/oliver/Desktop/DSP/rc_baseline/runs/phase4_residual_fusion/payload_inventory.json)
